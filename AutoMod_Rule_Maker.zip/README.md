# AutoMod-Rule-Maker

This is a tool to generate basic AutoModerator rule code.

To use this:

1. Install the latest version of [python](https://www.python.org/downloads/)
2. Save AutoMod_Rule_Maker.py anywhere you like
3. Open Command Prompt (or Terminal)
4. Type "python " then drag the .py file in and press enter.
