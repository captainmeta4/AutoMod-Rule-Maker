# AutoMod-Rule-Maker

This is a tool to generate basic AutoModerator rule code.

To use this:

1. Install the latest version of [python](https://www.python.org/downloads/)
2. Download AutoMod_Rule_Maker.zip and unpack it.
3. Double-click run.bat
